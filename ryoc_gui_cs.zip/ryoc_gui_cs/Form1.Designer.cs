﻿namespace ryoc_gui_cs
{
    partial class RollYourOwnCrypto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RollYourOwnCrypto));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rdo_128 = new System.Windows.Forms.RadioButton();
            this.rdo_256 = new System.Windows.Forms.RadioButton();
            this.rdo_512 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbx_salt = new System.Windows.Forms.CheckBox();
            this.btn_key = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_key = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_path = new System.Windows.Forms.TextBox();
            this.btn_browse = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_enc_dec = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(12, 32);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(1058, 26);
            this.txt_password.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Password";
            // 
            // rdo_128
            // 
            this.rdo_128.AutoSize = true;
            this.rdo_128.Location = new System.Drawing.Point(17, 4);
            this.rdo_128.Name = "rdo_128";
            this.rdo_128.Size = new System.Drawing.Size(115, 24);
            this.rdo_128.TabIndex = 2;
            this.rdo_128.TabStop = true;
            this.rdo_128.Text = "128-Bit Key";
            this.rdo_128.UseVisualStyleBackColor = true;
            // 
            // rdo_256
            // 
            this.rdo_256.AutoSize = true;
            this.rdo_256.Location = new System.Drawing.Point(213, 4);
            this.rdo_256.Name = "rdo_256";
            this.rdo_256.Size = new System.Drawing.Size(115, 24);
            this.rdo_256.TabIndex = 3;
            this.rdo_256.TabStop = true;
            this.rdo_256.Text = "256-Bit Key";
            this.rdo_256.UseVisualStyleBackColor = true;
            // 
            // rdo_512
            // 
            this.rdo_512.AutoSize = true;
            this.rdo_512.Location = new System.Drawing.Point(409, 4);
            this.rdo_512.Name = "rdo_512";
            this.rdo_512.Size = new System.Drawing.Size(115, 24);
            this.rdo_512.TabIndex = 4;
            this.rdo_512.TabStop = true;
            this.rdo_512.Text = "512-Bit Key";
            this.rdo_512.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdo_128);
            this.panel1.Controls.Add(this.rdo_512);
            this.panel1.Controls.Add(this.rdo_256);
            this.panel1.Location = new System.Drawing.Point(16, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 34);
            this.panel1.TabIndex = 5;
            // 
            // cbx_salt
            // 
            this.cbx_salt.AutoSize = true;
            this.cbx_salt.Location = new System.Drawing.Point(644, 74);
            this.cbx_salt.Name = "cbx_salt";
            this.cbx_salt.Size = new System.Drawing.Size(136, 24);
            this.cbx_salt.TabIndex = 6;
            this.cbx_salt.Text = "Salt Password";
            this.cbx_salt.UseVisualStyleBackColor = true;
            // 
            // btn_key
            // 
            this.btn_key.Location = new System.Drawing.Point(995, 69);
            this.btn_key.Name = "btn_key";
            this.btn_key.Size = new System.Drawing.Size(75, 34);
            this.btn_key.TabIndex = 7;
            this.btn_key.Text = "Get Key";
            this.btn_key.UseVisualStyleBackColor = true;
            this.btn_key.Click += new System.EventHandler(this.btn_key_Click);
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(12, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1058, 2);
            this.label2.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Key";
            // 
            // txt_key
            // 
            this.txt_key.Location = new System.Drawing.Point(12, 148);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(1058, 26);
            this.txt_key.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(10, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1058, 2);
            this.label4.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "File";
            // 
            // txt_path
            // 
            this.txt_path.Location = new System.Drawing.Point(12, 237);
            this.txt_path.Name = "txt_path";
            this.txt_path.ReadOnly = true;
            this.txt_path.Size = new System.Drawing.Size(929, 26);
            this.txt_path.TabIndex = 13;
            // 
            // btn_browse
            // 
            this.btn_browse.Location = new System.Drawing.Point(993, 233);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(75, 34);
            this.btn_browse.TabIndex = 14;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(10, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(1058, 2);
            this.label6.TabIndex = 15;
            // 
            // btn_enc_dec
            // 
            this.btn_enc_dec.Location = new System.Drawing.Point(451, 308);
            this.btn_enc_dec.Name = "btn_enc_dec";
            this.btn_enc_dec.Size = new System.Drawing.Size(176, 34);
            this.btn_enc_dec.TabIndex = 16;
            this.btn_enc_dec.Text = "Encrypt / Decrypt File";
            this.btn_enc_dec.UseVisualStyleBackColor = true;
            this.btn_enc_dec.Click += new System.EventHandler(this.btn_enc_dec_Click);
            // 
            // RollYourOwnCrypto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 354);
            this.Controls.Add(this.btn_enc_dec);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.txt_path);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_key);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_key);
            this.Controls.Add(this.cbx_salt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_password);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RollYourOwnCrypto";
            this.Text = "File Encryption / Decryption GUI";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdo_128;
        private System.Windows.Forms.RadioButton rdo_256;
        private System.Windows.Forms.RadioButton rdo_512;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cbx_salt;
        private System.Windows.Forms.Button btn_key;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_path;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_enc_dec;
    }
}

