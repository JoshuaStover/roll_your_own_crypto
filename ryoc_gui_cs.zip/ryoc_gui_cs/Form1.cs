﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ryoc_gui_cs
{
    public partial class RollYourOwnCrypto : Form
    {
        public RollYourOwnCrypto()
        {
            InitializeComponent();
        }

        private UInt32 bitwise_right(UInt32 number, UInt32 amount)
        {
            int bits = (int)(amount % 32);
            return (number >> bits) | (number << 32 - bits);
        }

        // Simple bitwise left rotation for 32-bit unsigned values
        private UInt32 bitwise_left(UInt32 number, UInt32 amount)
        {
            int bits = (int)(amount % 32);
            return (number << bits) | (number >> 32 - bits);
        }

        private UInt32[] digest(UInt32[] converted_pass, UInt32[] result, UInt16 arr_len)
        {
            for (UInt16 i = 0; i < arr_len / 16; i++)
            {
                // Loop though each group of 512 bits, compounding changes with each round
                result[0] += bitwise_left(result[0], converted_pass[16 * i] * converted_pass[16 * i]);
                result[1] += (converted_pass[(16 * i) + 1] ^ result[0]) * result[0];
                result[2] += (result[0] & converted_pass[(16 * i) + 2]) + result[1];
                result[3] += ((result[1] ^ result[2]) | converted_pass[(16 * i) + 3]) - result[2];
                result[4] += bitwise_left(result[3] & converted_pass[(16 * i) + 4], result[4]) + result[3];
                result[5] += bitwise_right(converted_pass[(16 * i) + 5], result[4]) + result[4];
                result[6] += (~converted_pass[(16 * i) + 6] ^ result[5]) * result[5];
                result[7] += bitwise_right(result[6] ^ result[5], converted_pass[(16 * i) + 7]) + result[6];
                result[8] += bitwise_left(result[5] + converted_pass[(16 * i) + 8], result[3]) - result[7];
                result[9] += (converted_pass[(16 * i) + 9] ^ ~result[7]) * result[8];
                result[10] += ((result[7] + converted_pass[(16 * i) + 10]) - result[8]) & result[9];
                result[11] += bitwise_right(converted_pass[(16 * i) + 11], result[3]) + result[10];
                result[12] += (converted_pass[(16 * i) + 12] + result[2]) * result[11];
                result[13] += (converted_pass[(16 * i) + 13] & result[1]) - ~result[12];
                result[14] += (result[12] ^ result[0]) + converted_pass[(16 * i) + 14];
                result[15] += (result[13] - converted_pass[(16 * i) + 15]) * (result[14] ^ result[12]);
            }
            return result;
        }

        private void salted_conversion(string user_pass, UInt32[] converted_pass, UInt16 vec_size)
        {
            for (UInt16 i = 0; i < vec_size; i++)
            {
                TimeSpan ts = DateTime.Now - new DateTime(1970, 1, 1);
                UInt32 CURRENT_TIME = (UInt32)ts.TotalSeconds;
                converted_pass[i] =
                bitwise_left(((UInt32)user_pass[4 * i] << (int)(CURRENT_TIME % 11)) + ((UInt32)user_pass[(4 * i) + 2] << (int)(CURRENT_TIME % 19)), 24)
                + bitwise_left(((UInt32)user_pass[(4 * i) + 1] << (int)(CURRENT_TIME % 13)) + ((UInt32)user_pass[(4 * i) + 3] << (int)(CURRENT_TIME % 17)), 16)
                + bitwise_left(((UInt32)user_pass[(4 * i) + 3] << (int)(CURRENT_TIME % 17)) + ((UInt32)user_pass[4 * i] << (int)(CURRENT_TIME % 11)), 8)
                + (((UInt32)user_pass[(4 * i) + 2]) << (int)(CURRENT_TIME % 19)) + (((UInt32)user_pass[(4 * i) + 1]) << (int)(CURRENT_TIME % 13));
            }
        }

        private void unsalted_conversion(string user_pass, UInt32[] converted_pass, UInt16 vec_size)
        {
            for (UInt16 i = 0; i < vec_size; i++)
            {
                converted_pass[i] =
                bitwise_left(((UInt32)user_pass[4 * i] << 11) + ((UInt32)user_pass[(4 * i) + 2] << 7), 24)
                + bitwise_left(((UInt32)user_pass[(4 * i) + 1] << 13) + ((UInt32)user_pass[(4 * i) + 3] << 11), 16)
                + bitwise_left(((UInt32)user_pass[(4 * i) + 3] << 17) + ((UInt32)user_pass[4 * i] << 13), 8)
                + (((UInt32)user_pass[(4 * i) + 2] << 19) + ((UInt32)user_pass[(4 * i) + 1] << 17));
            }
        }

        private string get512(UInt32[] digest)
        {
            string key = "";
            for (UInt16 i = 0; i < 16; i++) { key += digest[i].ToString("X8"); }
            return key;
        }

        private string get256(UInt32[] digest)
        {
            List<UInt32> to_256 = new List<UInt32>() {
                digest[0] + digest[8],
                digest[1] + digest[9],
                digest[2] + digest[10],
                digest[3] + digest[11],
                digest[4] + digest[12],
                digest[5] + digest[13],
                digest[6] + digest[14],
                digest[7] + digest[15]
            };
            string key = "";
            for (UInt16 i = 0; i < 8; i++) { key += to_256[i].ToString("X8"); }
            return key;
        }

        private string get128(UInt32[] digest)
        {
            List<UInt32> to_128 = new List<UInt32>() {
                (digest[0] & digest[8]) + (digest[4] ^ digest[12]),
                (digest[1] + digest[9]) * (digest[5] - digest[13]),
                (digest[2] ^ digest[10]) + (digest[6] & digest[14]),
                (digest[3] - digest[11]) * (digest[7] + digest[15])
            };
            string key = "";
            for (UInt16 i = 0; i < 4; i++) { key += to_128[i].ToString("X8"); }
            return key;
        }

        private byte[] key_to_ba(string key)
        {
            byte[] key_list = new byte[key.Length / 2];
            for (UInt16 i = 0; i < key.Length / 2; i++)
            {
                key_list[i] = Convert.ToByte(key.Substring(2 * i, 2), 16);
            }
            return key_list;
        }

        private void file_enc_dec(byte[] file_contents, string key, string path, Int32 len)
        {
            byte[] key_list = key_to_ba(key);

            for (Int32 i = 0; i < len - ((key.Length / 2) - 1); i++)
            {
                for (UInt16 j = 0; j < key.Length / 2; j++)
                {
                    file_contents[i + j] ^= key_list[j];
                }
            }

            File.WriteAllBytes(path, file_contents);
        }

        private void btn_key_Click(object sender, EventArgs e)
        {
            string password = txt_password.Text;

            if (password != "")
            {
                byte key_size = 3;

                if (rdo_128.Checked) { key_size = 1; }
                else if (rdo_256.Checked) { key_size = 2; }
                else { key_size = 3; }

                UInt32[] constants = 
                {
                    1415926535, 897932384, 4264338327, 2884197169,
                    3993751058, 2097494459, 2307816406, 2862089986,
                    2803482534, 2117067982, 1480865132, 823066470,
                    3844609550, 582231725, 3594081284, 811174502
                };
                UInt32 pass_length = (UInt32)password.Length;
                password += pass_length.ToString();

                while (password.Length % 64 != 0) { password += "0"; }

                UInt16 pass_list_size = (UInt16)(password.Length / 4);
                UInt32[] password_list = new UInt32[pass_list_size];

                if (cbx_salt.Checked) { salted_conversion(password, password_list, pass_list_size); }
                else { unsalted_conversion(password, password_list, pass_list_size); }

                switch (key_size)
                {
                    case 1:
                        txt_key.Text = get128(digest(password_list, constants, pass_list_size));
                        break;
                    case 2:
                        txt_key.Text = get256(digest(password_list, constants, pass_list_size));
                        break;
                    case 3:
                        txt_key.Text = get512(digest(password_list, constants, pass_list_size));
                        break;
                }
            }
            
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txt_path.Text = openFileDialog1.FileName;
            }
        }

        private void btn_enc_dec_Click(object sender, EventArgs e)
        {
            string key = txt_key.Text;
            string path = txt_path.Text;

            if ((key.Length > 0) && (path != ""))
            {
                byte[] file_content = File.ReadAllBytes(path);

                file_enc_dec(file_content, key, path, file_content.Length);

                MessageBox.Show("Encryption/Decryption Complete", "Alert");
            }
            

        }
    }
}
